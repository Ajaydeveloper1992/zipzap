export default function Categories() {

    return(
        <>
        <h1>Categories Mange</h1>
        </>
    );
}