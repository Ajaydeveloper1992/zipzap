import { createContext, useContext, useState, useEffect } from 'react';

// User context to hold user info
const UserContext = createContext();

export function UserProvider({ children }) {
    const [user, setUser] = useState(null);
    
    const login = async (identifier, password) => {
        const response = await fetch('/api/auth/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ identifier, password }),
        });

        const data = await response.json();

        if (response.ok) {
            setUser({
                id: data.id, // Ensure the server returns this
                username: data.username,
                email: data.email,
                role: data.role,
            });
        } else {
            throw new Error(data.error);
        }
    };

    const logout = async () => {
        setUser(null);
        await fetch('/api/auth/logout', { method: 'POST' }); // Ensure you have a logout endpoint
    };

    // Optional: Load user data from cookie on initial mount
    useEffect(() => {
        const loadUserData = async () => {
            const response = await fetch('/api/auth/me', { // Create an endpoint to get user data
                method: 'GET',
                credentials: 'include' // Ensure cookies are sent
            });
            if (response.ok) {
                const data = await response.json();
                setUser(data);
            }
        };

        loadUserData();
    }, []);

    return (
        <UserContext.Provider value={{ user, login, logout }}>
            {children}
        </UserContext.Provider>
    );
}

// Custom hook to use user context
export const useUser = () => useContext(UserContext);
