"use client"; // This makes it a Client Component

import { SessionProvider } from "next-auth/react"; // Import normally

export default function SessionProviderWrapper({ children }) {
  return <SessionProvider>{children}</SessionProvider>;
}