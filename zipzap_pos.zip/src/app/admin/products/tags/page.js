export default function Tags() {

    return(
        <>
        <h1>Tags Mange</h1>
        </>
    );
}