export default function Addnewproduct() {

        return(
            <>
            <h1>Add New Products</h1>
            </>
        );
}