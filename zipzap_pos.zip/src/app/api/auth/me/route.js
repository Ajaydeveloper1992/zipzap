import { getSession } from 'next-auth/react'; // Use your session management logic

export async function GET(req) {
    const session = await getSession({ req });
    
    if (session) {
        return new Response(JSON.stringify({
            id: session.user.id,
            username: session.user.username,
            email: session.user.email,
            role: session.user.role,
        }), {
            status: 200,
            headers: {
                'Content-Type': 'application/json',
            },
        });
    } else {
        return new Response(JSON.stringify({ error: 'Unauthorized' }), {
            status: 401,
            headers: {
                'Content-Type': 'application/json',
            },
        });
    }
}