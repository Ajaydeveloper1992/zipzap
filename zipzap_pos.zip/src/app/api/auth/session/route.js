import { getSession, setLoginSession } from "next-auth/react";

export async function GET(req) {
  const session = await getSession({ req });

  if (session) {
    // Session exists
    return new Response(JSON.stringify({ session }), { status: 200 });
  } else {
    // No session
    return new Response(JSON.stringify({ message: "Unauthorized" }), { status: 401 });
  }
}

export async function POST(req) {
  const sessionData = await req.json(); // Assuming session data is sent in the request body
  
  // Example: Set the login session (make sure setLoginSession is properly defined)
  await setLoginSession(sessionData); 

  return new Response(JSON.stringify({ message: "Session set successfully" }), { status: 200 });
}
 