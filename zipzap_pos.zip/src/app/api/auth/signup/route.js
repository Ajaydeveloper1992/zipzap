import dbConnect from "@/lib/dbConfig"; 
import User from "@/models/userModel";
import Role from "@/models/roleModel";  // Import your Role model
import { NextRequest, NextResponse } from "next/server";
import bcryptjs from "bcryptjs";

export async function POST(request) {
    // Establish a database connection
    await dbConnect();

    try {
        const reqBody = await request.json();
        const { username, email, fname, lname, phone, image, password } = reqBody;

        // Checks if a user with the provided email already exists. 
        const user = await User.findOne({ email });
        if (user) {
            return NextResponse.json({ error: "User already exists" }, { status: 400 });
        }

        // Find the role by name (you can change 'ruser' to whatever role you need)
        const role = await Role.findOne({ name: 'manger' });
        if (!role) {
            return NextResponse.json({ error: "Role not found" }, { status: 400 });
        }

        // Hash password using bcryptjs.
        const salt = await bcryptjs.genSalt(10);
        const hashedPassword = await bcryptjs.hash(password, salt);

        // Create a new user with the found role ID
        const newUser = new User({
            username,
            email,
            fname,
            lname,
            phone,
            image,
            role: role._id,  // Assign the role ID here
            password: hashedPassword
        });

        // Saves the new user to the database.
        const savedUser = await newUser.save();

        return NextResponse.json({
            message: "User created successfully",
            success: true,
            savedUser
        });

    } catch (error) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}