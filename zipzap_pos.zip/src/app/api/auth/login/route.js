/*import dbConnect from "@/lib/dbConfig";  
import User from "@/models/userModel";
import { NextRequest, NextResponse } from "next/server";
import bcryptjs from "bcryptjs";
import jwt from "jsonwebtoken";

export async function POST(request) {
    await dbConnect();
    try {
        const reqBody = await request.json();
        const { identifier, password } = reqBody;

        const user = await User.findOne({
            $or: [{ email: identifier }, { username: identifier }]
        });

        if (!user) {
            return NextResponse.json({ error: "User does not exist" }, { status: 400 });
        }

        const validPassword = await bcryptjs.compare(password, user.password);
        if (!validPassword) {
            return NextResponse.json({ error: "Invalid password" }, { status: 400 });
        }

        const tokenData = {
            id: user._id,
            username: user.username,
            email: user.email,
            role: user.role,
        };

        const token = jwt.sign(tokenData, process.env.NEXTAUTH_SECRET, { expiresIn: "1d" });

        const response = NextResponse.json({
            message: "Login successful",
            success: true,
            id: user._id, // Include user ID
            username: user.username,
            email: user.email,
            role: user.role,
        });

        response.cookies.set("token", token, {
            httpOnly: true,
        });

        return response;

    } catch (error) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}*/
// src/app/api/auth/login/route.js

import dbConnect from "@/lib/dbConfig";  
import User from "@/models/userModel";
import { NextRequest, NextResponse } from "next/server";
import bcryptjs from "bcryptjs";
import { getToken } from "next-auth/jwt"; // Import this for token handling
import { setLoginSession } from "@/lib/auth"; // Function to create session
import jwt from "jsonwebtoken";
export async function POST(request) {
    await dbConnect();
    try {
        const reqBody = await request.json();
        const { identifier, password } = reqBody;

        const user = await User.findOne({
            $or: [{ email: identifier }, { username: identifier }]
        });

        if (!user) {
            return NextResponse.json({ error: "User does not exist" }, { status: 400 });
        }

        const validPassword = await bcryptjs.compare(password, user.password);
        if (!validPassword) {
            return NextResponse.json({ error: "Invalid password" }, { status: 400 });
        }

        // Create the session
        const sessionData = {
            id: user._id,
            username: user.username,
            email: user.email,
            role: user.role,
        };

        await setLoginSession(sessionData); // Set the session
        const token = jwt.sign(sessionData, process.env.NEXTAUTH_SECRET, { expiresIn: "1d" });
        const response = NextResponse.json({
            message: "Login successful",
            success: true,
            id: user._id,
            username: user.username,
            email: user.email,
            role: user.role,
        });

        response.cookies.set("token", token, {
            httpOnly: true,
        });
        return response;
    } catch (error) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}