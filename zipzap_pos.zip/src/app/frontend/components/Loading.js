// Example of a default export
const Loading = () => {
  return <div>Loading...</div>;
};

export default Loading;